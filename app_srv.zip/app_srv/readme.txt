Dossier actuel : Application serveur ( JSON ) 

Tutos :
http://vogella.developpez.com/tutoriels/android/utilisation-format-json/x