<?

//Classe : conf.php
//Auteur : VERRIER Alexandre
//Date   : 25/02/15
//Texte  : Fichier de configuration général

//------------------------------------------------------------------------------
// Infos de connexion à la base de donnée
//------------------------------------------------------------------------------

$db1_name = 'u171774668_bdd';
$db1_user = 'u171774668_test';
$db1_password = 'YdTSHo0eUf';
$db1_server = 'mysql.hostinger.fr';
$db1_type = 'mysql';
